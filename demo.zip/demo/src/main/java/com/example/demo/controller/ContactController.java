package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.ContactIF;
import com.example.demo.model.Contact;


@RestController
@RequestMapping("/api/contact")
public class ContactController {
	
	@Autowired
	public ContactIF repositary;
	
	@PostMapping("/create/contact")
	public ResponseEntity<Contact> createContact( @RequestBody Contact dto){
		
		Contact createdcontact=this.repositary.createContact(dto);
		
		return new ResponseEntity<>(createdcontact,HttpStatus.CREATED);
	}
	
	@GetMapping("/getAll/contacts")
	public ResponseEntity<List<Contact>> getAllContactData(){
		
		return ResponseEntity.ok(this.repositary.getAllContacts());
	}
	
	@GetMapping("/{emailId}")
	public  ResponseEntity<Contact> getContactByEmailId(@PathVariable String emailId){
		
		return ResponseEntity.ok(this.repositary.getContactById(emailId));
	}
	
	


}
