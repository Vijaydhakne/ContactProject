package com.example.demo.Service;

import java.util.List;


import com.example.demo.model.Contact;

public interface ContactIF {
	
	Contact createContact(Contact user);
	
	List<Contact> getAllContacts();
	
	Contact getContactById(String emailId);
}
