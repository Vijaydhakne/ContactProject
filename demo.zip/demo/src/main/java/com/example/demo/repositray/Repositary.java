package com.example.demo.repositray;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Contact;

public interface Repositary extends JpaRepository<Contact, String> {
	
	public Contact findByEmailId(String emailId);

}
