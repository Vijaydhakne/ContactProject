package com.example.demo.ServiceImpl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import com.example.demo.Service.ContactIF;
import com.example.demo.model.Contact;
import com.example.demo.repositray.Repositary;

@Service
public class ContactImpl implements ContactIF {
	
	@Autowired
	public Repositary repositary;


	@Override
	public Contact createContact(Contact contact) {
		
		Contact savedcontact=this.repositary.save(contact);
		
		return savedcontact;
	}


	@Override
	public List<Contact> getAllContacts() {

		List<Contact>users=this.repositary.findAll();
		
		return users;
		
	}


	@Override
	public Contact getContactById(String emailId) {
		
		Contact contactdb=this.repositary.findByEmailId(emailId);
		
		return contactdb;
	}


	

}
