package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity

public class Address {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    @Column(name = "id")
	private Long id;
	
	private String location;
	
	private String streetName;
	
	private int pinCode;
	
	 @OneToOne(mappedBy = "address")
	private Contact  contact;

	public Address() {
		super();
		
	}

	public Address(String location, String streetName, int pinCode, Contact contact) {
		super();
		this.location = location;
		this.streetName = streetName;
		this.pinCode = pinCode;
		this.contact = contact;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	
	
	public Contact getContact() {
		return contact;
	}
	
	
	public void setContact(Contact contact) {
		this.contact = contact;
	}

	
	
	
	
	

}
